BitaxeHex 300 gerber files

4 copper layers
silkscreen on top and bottom

bitaxeHex-Edge_Cuts.gbr      -Board outline
bitaxeHex-F_Cu.gbr           -Top copper
bitaxeHex-B_Cu.gbr           -Bottom copper
bitaxeHex-F_Mask.gbr         -Top solder mask
bitaxeHex-B_Mask.gbr         -Bottom solder mask
bitaxeHex-F_Silkscreen.gbr   -Top silkscreen
bitaxeHex-B_Silkscreen.gbr   -Bottom silkscreen
bitaxeHex-F_Paste.gbr        -Top paste stencil
bitaxeHex-B_Paste.gbr        -Bottom paste stencil
bitaxeHex-In1_Cu.gbr         -Inner copper layer 1
bitaxeHex-In2_Cu.gbr         -Inner copper layer 2
bitaxeHex-PTH.drl            -drill plated-through holes
bitaxeHex-NPTH.drl           -drill non-plated through holes

