BitaxeHex Display gerber files

2 copper layers
silkscreen on top only

hex-display-Edge_Cuts.gbr      -Board outline
hex-display-F_Cu.gbr           -Top copper
hex-display-B_Cu.gbr           -Bottom copper
hex-display-F_Mask.gbr         -Top solder mask
hex-display-B_Mask.gbr         -Bottom solder mask
hex-display-F_Silkscreen.gbr   -Top silkscreen
hex-display-PTH.drl            -drill plated-through holes

